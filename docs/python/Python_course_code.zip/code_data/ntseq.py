"""file ntseq.py

Module 'ntseq': operations on NT sequences.
"""

complement_map = {'c': 'g', 'g': 'c', 'a': 't', 't': 'a'}

def reverse_complement(seq):
    "Return the reverse complement of an NT sequence."
    complist = map(complement_map.get, seq)
    complist.reverse()
    return ''.join(complist)

seq = 'cgtaacggtcaggttatattt'   # code to test the function
print seq
print reverse_complement(seq)
