"file t30.py"

from geom1 import *

i1 = Circle(0, 2)
i2 = Circle(-1, -1, 4)
i3 = i1

i1.radius = 1.75
print 'i1:', i1.radius
print 'i2:', i2.radius
print 'i3:', i3.radius
