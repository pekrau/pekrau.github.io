"file t25.py"

import sys

for dirname in sys.path:
    print dirname
