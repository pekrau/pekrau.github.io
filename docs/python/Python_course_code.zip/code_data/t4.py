"file t4.py"

s = 0
for i in [0, 1, 2, 3, 4, 5, 6, 7, 8]:
    s = s + i
    if s > 10:
        break

print "i=%i, s=%i" % (i, s)
