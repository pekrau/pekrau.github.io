"""file ntseq_mod.py

Module 'ntseq': operations on NT sequences.
"""

complement_map = {'c': 'g', 'g': 'c', 'a': 't', 't': 'a'}

def reverse_complement(seq):
    "Return the reverse complement of an NT sequence."
    complist = map(complement_map.get, seq)
    complist.reverse()
    return ''.join(complist)

if __name__ == '__main__':          # code to test the function
    seq = 'cgtaacggtcaggttatattt'
    print seq
    print reverse_complement(seq)
