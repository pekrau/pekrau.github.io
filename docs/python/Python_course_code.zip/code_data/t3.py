"file t3.py"

status_map = {'Luke': 'Jedi Knight',
              'Per': 'Pythonist'}

person = 'Luke'

print person, status_map.get(person, 'unknown')
