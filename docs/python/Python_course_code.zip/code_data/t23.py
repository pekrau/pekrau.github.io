"file t23.py"

import ntseq

seq = 'aaaccc'
print seq
print ntseq.reverse_complement(seq)
