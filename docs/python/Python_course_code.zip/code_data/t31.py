"file t31.py"

from geom1 import *

i1 = Circle(0, 2, 4)
print 'i1:', i1.radius, i1.area()
i1.radius = -2
print 'i1:', i1.radius, i1.area()
i1.radius = 'garbage'
print 'i1:', i1.radius, i1.area()
