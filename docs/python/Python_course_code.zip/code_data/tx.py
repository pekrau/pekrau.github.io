"file tx.py"

import ftplib

f = ftplib.FTP('ftp.python.org')
print f.login()
print f.retrlines('LIST')
