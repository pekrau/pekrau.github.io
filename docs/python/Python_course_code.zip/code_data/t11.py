"file t11.py"

def fixed_args(a, c, b):                            # note: order of args
    "Format arguments into a string and return."
    return "a=%s, b=%s, c=%s" % (a, b, c)           # '%s' converts to string

print fixed_args('stuff', 1.2, [2, 1])
