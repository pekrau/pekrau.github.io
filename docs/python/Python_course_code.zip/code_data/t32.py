"file t32.py"

from geom1 import *

i1 = Circle(0, 2)

i1.colour = 'red'                               # add an instance attribute
print 'i1:', i1.radius, i1.colour

del i1.radius                                   # delete an instance attribute
print 'has i1 radius?', hasattr(i1, 'radius')   # built-in function
print 'i1:', i1.area()
