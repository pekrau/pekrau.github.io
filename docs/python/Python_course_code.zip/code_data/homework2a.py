"file homework2a.py"

def read_file(filename):
    f = open(filename)
    result = []
    for line in f:
        parts = line.split()
        result.append(parts)
    f.close()
    return result

data = read_file('addresses.txt')

for parts in data:
    parts[1], parts[0] = parts[0], parts[1]

data.sort()                                     # sort handles lists

for parts in data:
    line = '\t'.join(parts)
    print line


