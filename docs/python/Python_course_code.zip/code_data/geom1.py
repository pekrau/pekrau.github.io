"file geom1.py: Module with classes for geometrical shapes, 1st try"

import math

class Circle:                           # class definition statement
    "A 2D circle."                      # documentation string

    def __init__(self, x, y, radius=1): # initialization method
        self.x = x                      # set the attributes of this instance
        self.y = y
        self.radius = radius

    def area(self):
        "Return the area of the shape."
        return math.pi * self.radius**2
