"file t10.py"

def all_items_positive(r):
    "Check that all values in list r are positive."
    for i in r:
        if i <= 0: return False
    return True

sequences = [[1, 5, 6, -0.01], [0.01, 1, 2]]

for seq in sequences:
    if not all_items_positive(seq):
        print 'invalid: ', seq
