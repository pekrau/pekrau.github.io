"file t26.py"

for name in dir():
    print "%r: %r" % (name, eval(name))
print
print 'virgin namespace:', dir()

import ntseq_mod
print 'after import:', dir()

from ntseq_mod import *
print 'after from:', dir()
