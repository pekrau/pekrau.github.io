"file t21.py"

complement_map = {'c': 'g', 'g': 'c', 'a': 't', 't': 'a'}

seq = 'cgtaacggtcaggttatattt'

complist = map(complement_map.get, seq)
complist.reverse()
revseq = ''.join(complist)

print seq
print revseq
