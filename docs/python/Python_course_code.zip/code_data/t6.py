"file t6.py"

s = 0
for i in xrange(10**6):
    if i % 19 == 0:
        s = s + i

print s
