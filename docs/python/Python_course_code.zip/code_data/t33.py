"file t33.py"

from geom2 import *

i1 = Circle(0, 2.5)
i2 = Circle(3, 4.02, 0)

print str(i1)
print 'is i1 a circle?:', bool(i1)
print 'is i2 a circle?:', bool(i2)
print 'i1 larger than i2?', i1 > i2
