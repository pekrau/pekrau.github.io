"file t34.py"

from geom2 import *

circles = [Circle(1, 3),
           Circle(0, 0, 0.2),
           Circle(-1, -1, 10.0)]
print circles                   # this uses 'repr', which calls __repr__

circles.sort()                  # this uses 'cmp', which calls __cmp__
print circles
