"file t35.py"

from geom3 import *

shapes = [Shape(),
          Circle(1, -2),
          Blob()]

for s in shapes:
    print s, 'round?', s.is_round()
