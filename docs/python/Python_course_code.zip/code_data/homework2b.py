"file homework2b.py"

def read_file(filename):
    f = open(filename)
    result = []
    for line in f:
        parts = line.split()
        result.append(parts)
    f.close()
    return result

def print_lines(lineslist):                 # better to make a func of it
    for parts in lineslist:
        print '\t'.join(parts)

data = read_file('addresses.txt')

for parts in data:
    parts[3], parts[0] = parts[0], parts[3]

data.sort()

print_lines(data)
