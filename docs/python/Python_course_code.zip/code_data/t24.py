"file t24.py"

import ntseq_mod

seq = 'aaaccc'
print seq
print ntseq_mod.reverse_complement(seq)
