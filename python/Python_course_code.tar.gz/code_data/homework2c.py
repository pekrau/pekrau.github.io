"file homework2c.py"

def read_file(filename):
    f = open(filename)
    result = []
    for line in f:
        parts = line.split()
        result.append(parts)
    f.close()
    return result

def print_lines(lineslist):
    for parts in lineslist:
        print '\t'.join(parts)

data = read_file('addresses.txt')

def compare_2(parts1, parts2):
    return cmp(parts1[2], parts2[2])

data.sort(compare_2)                    # use a custom-made comparison func

print_lines(data)                       # original order of items: good!
