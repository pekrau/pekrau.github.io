"file t28.py"

from geom1 import *

i1 = Circle(0, 2)           # '__init__' is called automatically
i2 = Circle(3, 0, 4)

print 'i1:', i1.radius, i1.area()
print 'i2:', i2.radius, i2.area()
print str(i1)

