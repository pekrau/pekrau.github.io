"file t5.py"

r = []
for c in 'this is a string with blanks':
    if c == ' ': continue
    r.append(c)

print ''.join(r)
