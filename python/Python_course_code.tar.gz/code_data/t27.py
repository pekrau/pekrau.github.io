"file t27.py"

print 'virgin namespace:', dir()

from math import exp
from math import log as natural_logarithm

print 'selective import:', dir()
print 'exp(1.0)=', exp(1.0)
print 'natural_logarithm(10.0)=', natural_logarithm(10.0)
