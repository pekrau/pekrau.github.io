"file homework1b.py"

def is_nt(seq):
    for c in seq.lower():
        if not c in "actg":
            return False
    return True

amino_acids = {'a': 1, 'v': 1, 'i': 1, 'l': 1, 'm': 1,
               'e': 1, 'd': 1, 'r': 1, 'k': 1, 'h': 1,
               'p': 1, 'f': 1, 'y': 1, 'w': 1, 'g': 1,
               'c': 1, 's': 1, 't': 1, 'n': 1, 'q': 1}

def is_aa(seq):
    for c in seq.lower():
        if not amino_acids.has_key(c):
            return False
    return True

def test(seqname, seq):
    if is_nt(seq):
        print seqname, ' is NT'
    elif is_aa(seq):
        print seqname, ' is AA'
    else:
        print seqname, ' is something else'

if __name__ == '__main__':
    for name, seq in [('seq1', 'cctgagtcgagatagcctctgata'),
                      ('seq2', 'NASWWKLHFGIIRTPASDDEANMCQW'),
                      ('seq3', 'alqpwoiwukahshdjcbvna')]:
        test(name, seq)
