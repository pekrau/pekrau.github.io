"file homework1a.py"

def is_nt(seq):
    for c in seq.lower():
        if not c in "actg":
            return False
    return True

amino_acids = {'a': 1, 'v': 1, 'i': 1, 'l': 1, 'm': 1,
               'e': 1, 'd': 1, 'r': 1, 'k': 1, 'h': 1,
               'p': 1, 'f': 1, 'y': 1, 'w': 1, 'g': 1,
               'c': 1, 's': 1, 't': 1, 'n': 1, 'q': 1}

def is_aa(seq):
    for c in seq.lower():
        if not amino_acids.has_key(c):
            return False
    return True

seq1 = 'cctgagtcgagatagcctctgata'
seq2 = 'NASWWKLHFGIIRTPASDDEANMCQW'
seq3 = 'alqpwoiwukahshdjcbvna'

if is_nt(seq1):
    print 'seq1 is NT'
elif is_aa(seq1):
    print 'seq1 is AA'
else:
    print 'seq1 is something else'

if is_nt(seq2):
    print 'seq2 is NT'
elif is_aa(seq2):
    print 'seq2 is AA'
else:
    print 'seq2 is something else'

if is_nt(seq3):
    print 'seq3 is NT'
elif is_aa(seq3):
    print 'seq3 is AA'
else:
    print 'seq3 is something else'
