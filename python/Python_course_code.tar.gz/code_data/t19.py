"file t19.py"

from math import *

def print_calc(f):
    print "log(%s)=%s, exp(%s)=%s" % (f, log(f), f, exp(f))

print_calc(1.0)
log, exp = exp, log       # evil code! swap the objects the names refer to
print_calc(1.0)
