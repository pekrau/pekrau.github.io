"file homework2d.py"

def read_file(filename):
    f = open(filename)
    result = []
    for line in f:
        line = line.rstrip()            # get rid of last newline char
        parts = line.split('\t')        # split at tab character only!
        result.append(parts)
    f.close()
    return result

def print_lines(lineslist):
    for parts in lineslist:
        print '\t'.join(parts)

data = read_file('addresses2.txt')

def compare_1(parts1, parts2):
    return cmp(parts1[1], parts2[1])

data.sort(compare_1)                    # use a custom-made comparison func

print_lines(data)                       # original order of items: good!
