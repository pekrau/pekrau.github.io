"file t7.py"

r = []
n = 0
last = 20

while n <= last:
    r.append(str(n))
    n += 3

print ', '.join(r)
