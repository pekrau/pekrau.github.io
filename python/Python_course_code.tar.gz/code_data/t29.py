"file t29.py"

from geom1 import *

i1 = Circle(0, 2)
print 'i1:', i1.radius, i1.area()

i1.radius = 2.5                     # change the value of an attribute
print 'i1:', i1.radius, i1.area()
