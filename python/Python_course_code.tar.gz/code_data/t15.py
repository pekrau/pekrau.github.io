"file t15.py"

def fixed_args(a, c, b):
    assert type(a) == type(1), "'a' must be an integer"
    return "a=%s, b=%s, c=%s" % (a, b, c)

print fixed_args('a', 1.2, [2, 1])
