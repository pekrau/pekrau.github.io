"file t14.py"

def keyword_args(a, b='bla', **kwargs):
    return "a=%s, b=%s, kwargs=%s" % (a, b, str(kwargs))

print keyword_args('stuff', c='call')
print keyword_args('stuff', c='call', b='apa')
print keyword_args(c='call', d=12, a='gr')
