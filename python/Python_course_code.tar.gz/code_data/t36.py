"file t36.py"

from bioseq import *

def fetch_seq(acc):
    for cls in [Nucleotide, Protein]:
        try:
            result = cls()
            result.fetch(acc)
            return result
        except IOError:
            pass
    return None

print fetch_seq('A123')
