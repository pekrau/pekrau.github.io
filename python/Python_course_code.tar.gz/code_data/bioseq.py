"file bioseq.py  Module to handle NT or AA sequences. Incomplete."

class Bioseq:
    
    def __init__(self, seq=None):
        self.seq = seq
        
    def fetch(self, acc):
        pass                # to be defined in inheriting classes


class Nucleotide(Bioseq):

    def fetch(self, acc):
        pass                # code to fetch from EMBL

    def translate(self):
        pass                # code to translate NT seq to AA
        return Protein(seq='whatever')


class Protein(Bioseq):

    def fetch(self, acc):
        pass                # code to fetch from Swiss-Prot
