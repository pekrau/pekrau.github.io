"file t18.py"

from math import *              # import everything from module 'math'

print e, pi
print cos(radians(180.0))
print log(10.0)
print exp(-1.0)
