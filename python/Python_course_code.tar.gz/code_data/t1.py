"file t1.py"              # this is a document string
print "Hello world!"
