"file t2.py"

person = 'Luke'

if person == 'Per':
    status = 'Pythonist'
elif person == 'Luke':
    status = 'Jedi knight'
else:
    status = 'unknown'

print person, status
