"file geom2.py: Module with classes for geometrical shapes, 2nd try"

import math

class Circle:                           # class definition statement
    "A 2D circle."                      # documentation string

    def __init__(self, x, y, radius=1): # initialization method
        self.x = x                      # set the attributes of this instance
        self.y = y
        self.radius = radius

    def area(self):
        "Return the area of the shape."
        return math.pi * self.radius**2

    def __repr__(self):                 # better string representation
        return "Circle(%g, %g, radius=%g)" % (self.x, self.y, self.radius)

    def __nonzero__(self):              # is a true circle? else point
        return self.radius != 0

    def __cmp__(self, other):           # compare with other: larger or not?
        return cmp(self.radius, other.radius)
