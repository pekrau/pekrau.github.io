"file geom3.py: Module with classes for geometrical shapes, 2nd try"

import math

class Shape:                            # This is a base class
    "General geometrical shape."

    def is_round(self):
        return True


class Circle(Shape):                    # Circle inherits Shape
    "A 2D circle." 

    def __init__(self, x, y, radius=1): # initialization method
        self.x = x                      # set the attributes of this instance
        self.y = y
        self.radius = radius

    def area(self):
        "Return the area of the shape."
        return math.pi * self.radius**2

    def __repr__(self):                 # better string representation
        return "Circle(%g, %g, radius=%g)" % (self.x, self.y, self.radius)

    def __nonzero__(self):              # is a circle? if point: no
        return self.radius != 0

    def __cmp__(self, other):           # compare with other: larger or not?
        return cmp(self.radius, other.radius)


class Blob(Shape):
    "An undefined blob."

    def is_round(self):                 # overrides method from Shape
        return False
