"file t8.py"

r = [1, 3, 10, 98, -2, 48]

for i in r:
    if i < 0:
        print 'input contains negative value!'
        break
    else:
        pass
else:
    print 'input is OK'
