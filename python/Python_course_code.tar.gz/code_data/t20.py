"file t20.py"

infile = open('test.txt')               # read-only mode
outfile = open('test_upper.txt', 'w')   # write mode; creates the file

for line in infile:
    outfile.write(line.upper())

infile.close()                   # not strictly required; done automatically
outfile.close()
